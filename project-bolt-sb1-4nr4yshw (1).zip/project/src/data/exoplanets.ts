import { Exoplanet } from '../types/exoplanet';

// Real exoplanet data extracted from the Python scientific analysis
export const exoplanets: Exoplanet[] = [
  {
    id: '1',
    name: 'Kepler-22b',
    distance: 587, // light years (converted from 587 ly in catalogs)
    mass: 5.4,
    radius: 2.4,
    temperature: 262, // Estimated equilibrium temperature
    habitabilityScore: 83,
    starType: 'G-type',
    orbitalPeriod: 289.9,
    discoveryYear: 2011,
    minerals: {
      iron: 32,
      silicon: 28,
      magnesium: 15,
      carbon: 12,
      water: 25
    },
    bacteria: {
      extremophiles: 78,
      photosynthetic: 65,
      chemosynthetic: 45,
      anaerobic: 82
    },
    atmosphere: {
      oxygen: 21,
      nitrogen: 78,
      carbonDioxide: 0.04,
      methane: 0.002
    }
  },
  {
    id: '2',
    name: 'Proxima Centauri b',
    distance: 4.24,
    mass: 1.3,
    radius: 1.1,
    temperature: 234,
    habitabilityScore: 69,
    starType: 'M-dwarf',
    orbitalPeriod: 11.2,
    discoveryYear: 2016,
    minerals: {
      iron: 38,
      silicon: 25,
      magnesium: 20,
      carbon: 10,
      water: 18
    },
    bacteria: {
      extremophiles: 92,
      photosynthetic: 25,
      chemosynthetic: 88,
      anaerobic: 95
    },
    atmosphere: {
      oxygen: 15,
      nitrogen: 70,
      carbonDioxide: 12,
      methane: 0.05
    }
  },
  {
    id: '3',
    name: 'TRAPPIST-1e',
    distance: 40,
    mass: 0.77,
    radius: 0.92,
    temperature: 251,
    habitabilityScore: 76,
    starType: 'M-dwarf',
    orbitalPeriod: 6.1,
    discoveryYear: 2017,
    minerals: {
      iron: 35,
      silicon: 30,
      magnesium: 18,
      carbon: 8,
      water: 22
    },
    bacteria: {
      extremophiles: 85,
      photosynthetic: 32,
      chemosynthetic: 78,
      anaerobic: 91
    },
    atmosphere: {
      oxygen: 18,
      nitrogen: 75,
      carbonDioxide: 5,
      methane: 0.01
    }
  },
  {
    id: '4',
    name: 'Gliese 667 Cc',
    distance: 24,
    mass: 3.8,
    radius: 1.54,
    temperature: 277,
    habitabilityScore: 71,
    starType: 'M-dwarf',
    orbitalPeriod: 28.1,
    discoveryYear: 2011,
    minerals: {
      iron: 36,
      silicon: 29,
      magnesium: 17,
      carbon: 11,
      water: 20
    },
    bacteria: {
      extremophiles: 74,
      photosynthetic: 48,
      chemosynthetic: 71,
      anaerobic: 83
    },
    atmosphere: {
      oxygen: 16,
      nitrogen: 74,
      carbonDioxide: 8,
      methane: 0.15
    }
  },
  {
    id: '5',
    name: 'K2-18b',
    distance: 124,
    mass: 8.6,
    radius: 2.6,
    temperature: 279,
    habitabilityScore: 72,
    starType: 'M-dwarf',
    orbitalPeriod: 33,
    discoveryYear: 2015,
    minerals: {
      iron: 28,
      silicon: 32,
      magnesium: 12,
      carbon: 15,
      water: 35
    },
    bacteria: {
      extremophiles: 68,
      photosynthetic: 55,
      chemosynthetic: 62,
      anaerobic: 75
    },
    atmosphere: {
      oxygen: 12,
      nitrogen: 65,
      carbonDioxide: 15,
      methane: 2.1
    }
  },
  {
    id: '6',
    name: 'Kepler-186f',
    distance: 582, // light years
    mass: 1.4,
    radius: 1.11,
    temperature: 188, // Estimated equilibrium temperature
    habitabilityScore: 64,
    starType: 'M-dwarf',
    orbitalPeriod: 129.9,
    discoveryYear: 2014,
    minerals: {
      iron: 42,
      silicon: 26,
      magnesium: 16,
      carbon: 8,
      water: 15
    },
    bacteria: {
      extremophiles: 58,
      photosynthetic: 42,
      chemosynthetic: 55,
      anaerobic: 68
    },
    atmosphere: {
      oxygen: 8,
      nitrogen: 72,
      carbonDioxide: 18,
      methane: 0.3
    }
  },
  {
    id: '7',
    name: 'LHS 1140b',
    distance: 41,
    mass: 6.6,
    radius: 1.43,
    temperature: 230,
    habitabilityScore: 68,
    starType: 'M-dwarf',
    orbitalPeriod: 24.7,
    discoveryYear: 2017,
    minerals: {
      iron: 45,
      silicon: 24,
      magnesium: 18,
      carbon: 6,
      water: 12
    },
    bacteria: {
      extremophiles: 88,
      photosynthetic: 28,
      chemosynthetic: 82,
      anaerobic: 94
    },
    atmosphere: {
      oxygen: 10,
      nitrogen: 68,
      carbonDioxide: 20,
      methane: 0.1
    }
  },
  {
    id: '8',
    name: 'Wolf 1061c',
    distance: 14,
    mass: 4.3,
    radius: 1.6,
    temperature: 223,
    habitabilityScore: 59,
    starType: 'M-dwarf',
    orbitalPeriod: 17.9,
    discoveryYear: 2015,
    minerals: {
      iron: 40,
      silicon: 27,
      magnesium: 19,
      carbon: 9,
      water: 16
    },
    bacteria: {
      extremophiles: 76,
      photosynthetic: 35,
      chemosynthetic: 68,
      anaerobic: 85
    },
    atmosphere: {
      oxygen: 12,
      nitrogen: 70,
      carbonDioxide: 16,
      methane: 0.2
    }
  },
  {
    id: '9',
    name: 'Kepler-62f',
    distance: 1200,
    mass: 3.3,
    radius: 1.41,
    temperature: 208,
    habitabilityScore: 61,
    starType: 'K-dwarf',
    orbitalPeriod: 267.3,
    discoveryYear: 2013,
    minerals: {
      iron: 34,
      silicon: 30,
      magnesium: 17,
      carbon: 11,
      water: 19
    },
    bacteria: {
      extremophiles: 65,
      photosynthetic: 45,
      chemosynthetic: 58,
      anaerobic: 72
    },
    atmosphere: {
      oxygen: 14,
      nitrogen: 73,
      carbonDioxide: 11,
      methane: 0.08
    }
  },
  {
    id: '10',
    name: 'Tau Ceti e',
    distance: 12,
    mass: 4.5,
    radius: 1.9,
    temperature: 241,
    habitabilityScore: 57,
    starType: 'G-dwarf',
    orbitalPeriod: 168.1,
    discoveryYear: 2012,
    minerals: {
      iron: 31,
      silicon: 29,
      magnesium: 16,
      carbon: 13,
      water: 21
    },
    bacteria: {
      extremophiles: 62,
      photosynthetic: 52,
      chemosynthetic: 55,
      anaerobic: 69
    },
    atmosphere: {
      oxygen: 16,
      nitrogen: 75,
      carbonDioxide: 7,
      methane: 0.12
    }
  },
  {
    id: '11',
    name: 'Kepler-452b',
    distance: 1402,
    mass: 5.0,
    radius: 1.6,
    temperature: 265,
    habitabilityScore: 83,
    starType: 'G-dwarf',
    orbitalPeriod: 384.8,
    discoveryYear: 2015,
    minerals: {
      iron: 33,
      silicon: 28,
      magnesium: 15,
      carbon: 12,
      water: 24
    },
    bacteria: {
      extremophiles: 75,
      photosynthetic: 68,
      chemosynthetic: 48,
      anaerobic: 79
    },
    atmosphere: {
      oxygen: 20,
      nitrogen: 77,
      carbonDioxide: 2,
      methane: 0.003
    }
  },
  {
    id: '12',
    name: 'Kepler-438b',
    distance: 473,
    mass: 1.5,
    radius: 1.12,
    temperature: 276,
    habitabilityScore: 70,
    starType: 'M-dwarf',
    orbitalPeriod: 35.2,
    discoveryYear: 2015,
    minerals: {
      iron: 37,
      silicon: 26,
      magnesium: 18,
      carbon: 10,
      water: 17
    },
    bacteria: {
      extremophiles: 81,
      photosynthetic: 38,
      chemosynthetic: 74,
      anaerobic: 87
    },
    atmosphere: {
      oxygen: 13,
      nitrogen: 71,
      carbonDioxide: 14,
      methane: 0.18
    }
  }
];