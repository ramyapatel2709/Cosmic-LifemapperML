import React from 'react';
import { Exoplanet } from '../types/exoplanet';
import { ArrowLeft, Calendar, Globe, Thermometer, Star, Clock, Gauge } from 'lucide-react';
import { HabitabilityCard } from './HabitabilityCard';
import { MineralsChart } from './MineralsChart';
import { BacteriaChart } from './BacteriaChart';
import { ScientificAnalysis } from './ScientificAnalysis';

interface ExoplanetDetailProps {
  exoplanet: Exoplanet;
  onBack: () => void;
}

export const ExoplanetDetail: React.FC<ExoplanetDetailProps> = ({ exoplanet, onBack }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-purple-900 relative overflow-hidden">
      {/* Cosmic Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent"></div>
      <div className="absolute top-0 left-0 w-full h-full opacity-40" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Ccircle cx='30' cy='30' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
      }}></div>
      
      <div className="relative z-10 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center mb-8">
            <button
              onClick={onBack}
              className="flex items-center space-x-3 text-white hover:text-cyan-400 transition-all duration-300 bg-black/30 backdrop-blur-sm px-4 py-2 rounded-xl border border-gray-700/50 hover:border-cyan-500/50"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Return to Cosmos</span>
            </button>
          </div>

          <div className="bg-gradient-to-br from-gray-900/80 via-black/60 to-gray-900/80 backdrop-blur-xl rounded-2xl p-8 mb-8 border border-cyan-500/30 shadow-2xl shadow-cyan-500/10">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent mb-3">{exoplanet.name}</h1>
                <div className="flex items-center space-x-2">
                  <Calendar className="w-5 h-5 text-gray-400" />
                  <p className="text-gray-300 text-lg">Discovered in {exoplanet.discoveryYear}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center space-x-3 mb-3">
                  <Gauge className="w-6 h-6 text-cyan-400" />
                  <span className="text-white font-semibold text-lg">Habitability Score</span>
                </div>
                <div className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">{exoplanet.habitabilityScore}/100</div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-gradient-to-br from-blue-900/40 to-black/60 backdrop-blur-sm rounded-xl p-6 text-center border border-blue-500/30 hover:border-blue-400/50 transition-all duration-300">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Globe className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold mb-2">Distance</h3>
                <p className="text-3xl font-bold text-blue-400 mb-1">{exoplanet.distance}</p>
                <p className="text-sm text-gray-400">light years</p>
              </div>
              <div className="bg-gradient-to-br from-red-900/40 to-black/60 backdrop-blur-sm rounded-xl p-6 text-center border border-red-500/30 hover:border-red-400/50 transition-all duration-300">
                <div className="w-12 h-12 bg-gradient-to-r from-red-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Thermometer className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold mb-2">Temperature</h3>
                <p className="text-3xl font-bold text-red-400 mb-1">{exoplanet.temperature}</p>
                <p className="text-sm text-gray-400">Kelvin</p>
              </div>
              <div className="bg-gradient-to-br from-yellow-900/40 to-black/60 backdrop-blur-sm rounded-xl p-6 text-center border border-yellow-500/30 hover:border-yellow-400/50 transition-all duration-300">
                <div className="w-12 h-12 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold mb-2">Mass</h3>
                <p className="text-3xl font-bold text-yellow-400 mb-1">{exoplanet.mass}</p>
                <p className="text-sm text-gray-400">Earth masses</p>
              </div>
              <div className="bg-gradient-to-br from-green-900/40 to-black/60 backdrop-blur-sm rounded-xl p-6 text-center border border-green-500/30 hover:border-green-400/50 transition-all duration-300">
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold mb-2">Orbital Period</h3>
                <p className="text-3xl font-bold text-green-400 mb-1">{exoplanet.orbitalPeriod}</p>
                <p className="text-sm text-gray-400">Earth days</p>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-8">
            <HabitabilityCard exoplanet={exoplanet} />
            <ScientificAnalysis exoplanet={exoplanet} />
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-8">
            <div className="bg-gradient-to-br from-gray-900/80 via-black/60 to-gray-900/80 backdrop-blur-xl rounded-2xl p-8 border border-purple-500/30 shadow-2xl shadow-purple-500/10">
              <h3 className="text-2xl font-bold text-white mb-8 flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"></div>
                <span>Atmospheric Composition</span>
              </h3>
              <div className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300 font-medium">Nitrogen</span>
                    <span className="text-white font-bold">{exoplanet.atmosphere.nitrogen}%</span>
                  </div>
                  <div className="w-full bg-gray-800/50 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-3 rounded-full bg-gradient-to-r from-blue-400 to-cyan-500 shadow-lg"
                      style={{ width: `${exoplanet.atmosphere.nitrogen}%` }}
                    ></div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300 font-medium">Oxygen</span>
                    <span className="text-white font-bold">{exoplanet.atmosphere.oxygen}%</span>
                  </div>
                  <div className="w-full bg-gray-800/50 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-3 rounded-full bg-gradient-to-r from-green-400 to-emerald-500 shadow-lg"
                      style={{ width: `${exoplanet.atmosphere.oxygen * 4}%` }}
                    ></div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300 font-medium">Carbon Dioxide</span>
                    <span className="text-white font-bold">{exoplanet.atmosphere.carbonDioxide}%</span>
                  </div>
                  <div className="w-full bg-gray-800/50 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-3 rounded-full bg-gradient-to-r from-orange-400 to-red-500 shadow-lg"
                      style={{ width: `${exoplanet.atmosphere.carbonDioxide * 5}%` }}
                    ></div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300 font-medium">Methane</span>
                    <span className="text-white font-bold">{exoplanet.atmosphere.methane}%</span>
                  </div>
                  <div className="w-full bg-gray-800/50 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-3 rounded-full bg-gradient-to-r from-purple-400 to-violet-500 shadow-lg"
                      style={{ width: `${Math.min(100, exoplanet.atmosphere.methane * 50)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
            <MineralsChart exoplanet={exoplanet} />
          </div>

          <div className="grid lg:grid-cols-1 gap-8">
            <BacteriaChart exoplanet={exoplanet} />
          </div>
        </div>
      </div>
    </div>
  );
};