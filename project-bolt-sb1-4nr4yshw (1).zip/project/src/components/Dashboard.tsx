import React, { useState } from 'react';
import { exoplanets } from '../data/exoplanets';
import { ExoplanetCard } from './ExoplanetCard';
import { Search, Filter, Rocket, BarChart3 } from 'lucide-react';

interface DashboardProps {
  onExoplanetSelect: (id: string) => void;
  onCompareClick: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onExoplanetSelect, onCompareClick }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'habitability' | 'distance'>('habitability');

  const filteredExoplanets = exoplanets
    .filter(planet => 
      planet.name.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'habitability':
          return b.habitabilityScore - a.habitabilityScore;
        case 'distance':
          return a.distance - b.distance;
        default:
          return 0;
      }
    });

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-purple-900 relative overflow-hidden">
      {/* Cosmic Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent"></div>
      <div className="absolute top-0 left-0 w-full h-full opacity-40" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Ccircle cx='30' cy='30' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
      }}></div>
      
      <div className="relative z-10 p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center space-x-4 mb-6">
              <div className="relative">
                <Rocket className="w-16 h-16 text-cyan-400 animate-pulse" />
                <div className="absolute -inset-2 bg-cyan-400/20 rounded-full blur-xl"></div>
              </div>
              <h1 className="text-6xl font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent drop-shadow-2xl">
                Cosmic-LifeMapper
              </h1>
            </div>
            <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
              Journey through the cosmos to discover potentially habitable worlds beyond our solar system. 
              Explore their mysterious compositions, analyze their life potential, and compare their unique cosmic signatures.
            </p>
          </div>

          {/* Search and Controls */}
          <div className="bg-gradient-to-r from-gray-900/80 via-black/60 to-gray-900/80 backdrop-blur-xl rounded-2xl p-8 mb-8 border border-cyan-500/30 shadow-2xl shadow-cyan-500/10">
            <div className="flex flex-col md:flex-row gap-6 items-center justify-between">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-cyan-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search the cosmos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-black/50 border border-gray-700/50 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50 backdrop-blur-sm transition-all duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-xl opacity-0 hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
              </div>
              
              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-3">
                  <Filter className="w-5 h-5 text-purple-400" />
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as 'name' | 'habitability' | 'distance')}
                    className="bg-black/50 border border-gray-700/50 rounded-xl text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500/50 backdrop-blur-sm transition-all duration-300"
                  >
                    <option value="habitability">Sort by Habitability</option>
                    <option value="distance">Sort by Distance</option>
                    <option value="name">Sort by Name</option>
                  </select>
                </div>
                
                <button
                  onClick={onCompareClick}
                  className="flex items-center space-x-3 bg-gradient-to-r from-cyan-600 via-blue-600 to-purple-600 hover:from-cyan-500 hover:via-blue-500 hover:to-purple-500 px-6 py-3 rounded-xl text-white font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg shadow-cyan-500/25"
                >
                  <BarChart3 className="w-5 h-5" />
                  <span>Compare Worlds</span>
                </button>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="bg-gradient-to-br from-cyan-900/40 via-blue-900/30 to-black/60 backdrop-blur-xl rounded-2xl p-8 border border-cyan-500/30 shadow-2xl shadow-cyan-500/10 hover:shadow-cyan-500/20 transition-all duration-300">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-lg">{exoplanets.length}</span>
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-white mb-1">{exoplanets.length}</h3>
                  <p className="text-cyan-300 font-medium">Worlds Discovered</p>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-emerald-900/40 via-green-900/30 to-black/60 backdrop-blur-xl rounded-2xl p-8 border border-emerald-500/30 shadow-2xl shadow-emerald-500/10 hover:shadow-emerald-500/20 transition-all duration-300">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-lg">{exoplanets.filter(p => p.habitabilityScore >= 70).length}</span>
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-white mb-1">
                    {exoplanets.filter(p => p.habitabilityScore >= 70).length}
                  </h3>
                  <p className="text-emerald-300 font-medium">Life Candidates</p>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-purple-900/40 via-violet-900/30 to-black/60 backdrop-blur-xl rounded-2xl p-8 border border-purple-500/30 shadow-2xl shadow-purple-500/10 hover:shadow-purple-500/20 transition-all duration-300">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-violet-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-lg">{Math.round(exoplanets.reduce((acc, p) => acc + p.habitabilityScore, 0) / exoplanets.length)}</span>
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-white mb-1">
                    {Math.round(exoplanets.reduce((acc, p) => acc + p.habitabilityScore, 0) / exoplanets.length)}%
                  </h3>
                  <p className="text-purple-300 font-medium">Avg Habitability</p>
                </div>
              </div>
            </div>
          </div>

          {/* Exoplanet Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredExoplanets.map((exoplanet) => (
              <ExoplanetCard
                key={exoplanet.id}
                exoplanet={exoplanet}
                onClick={() => onExoplanetSelect(exoplanet.id)}
              />
            ))}
          </div>

          {filteredExoplanets.length === 0 && (
            <div className="text-center py-16">
              <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-r from-gray-700 to-gray-800 rounded-full flex items-center justify-center">
                <Search className="w-12 h-12 text-gray-400" />
              </div>
              <p className="text-gray-400 text-xl">No cosmic worlds found matching your search criteria.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};