import React, { useState } from 'react';
import { Exoplanet } from '../types/exoplanet';
import { exoplanets } from '../data/exoplanets';
import { ArrowLeft, ArrowRight, Globe, Thermometer, Star, Clock } from 'lucide-react';

interface ComparisonToolProps {
  onBack: () => void;
}

export const ComparisonTool: React.FC<ComparisonToolProps> = ({ onBack }) => {
  const [selectedPlanets, setSelectedPlanets] = useState<[Exoplanet | null, Exoplanet | null]>([null, null]);

  const handlePlanetSelect = (planet: Exoplanet, index: 0 | 1) => {
    const newSelection: [Exoplanet | null, Exoplanet | null] = [...selectedPlanets];
    newSelection[index] = planet;
    setSelectedPlanets(newSelection);
  };

  const ComparisonCard: React.FC<{ planet: Exoplanet | null; index: 0 | 1 }> = ({ planet, index }) => {
    if (!planet) {
      return (
        <div className="bg-gradient-to-br from-gray-900/80 via-black/60 to-gray-900/80 backdrop-blur-xl rounded-2xl p-8 border border-gray-700/50 border-dashed hover:border-cyan-500/50 transition-all duration-300">
          <h3 className="text-xl font-bold text-gray-400 mb-6 text-center">Select Cosmic World {index + 1}</h3>
          <div className="space-y-3">
            {exoplanets.map((p) => (
              <button
                key={p.id}
                onClick={() => handlePlanetSelect(p, index)}
                className="w-full text-left p-4 rounded-xl bg-black/40 hover:bg-gradient-to-r hover:from-cyan-900/30 hover:to-purple-900/30 transition-all duration-300 text-white border border-gray-700/30 hover:border-cyan-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={selectedPlanets.includes(p)}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{p.name}</span>
                  <span className="text-sm text-gray-400">{p.habitabilityScore}% habitable</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      );
    }

    return (
      <div className="bg-gradient-to-br from-gray-900/80 via-black/60 to-gray-900/80 backdrop-blur-xl rounded-2xl p-8 border border-cyan-500/30 shadow-2xl shadow-cyan-500/10">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">{planet.name}</h3>
          <button
            onClick={() => handlePlanetSelect(null as any, index)}
            className="text-gray-400 hover:text-cyan-400 transition-colors duration-300 px-3 py-1 rounded-lg hover:bg-black/30"
          >
            Change
          </button>
        </div>

        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-gradient-to-br from-blue-900/40 to-black/60 rounded-xl border border-blue-500/30">
              <Globe className="w-8 h-8 text-blue-400 mx-auto mb-3" />
              <p className="text-xs text-gray-400 mb-1">Distance</p>
              <p className="text-lg font-bold text-white">{planet.distance} ly</p>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-red-900/40 to-black/60 rounded-xl border border-red-500/30">
              <Thermometer className="w-8 h-8 text-red-400 mx-auto mb-3" />
              <p className="text-xs text-gray-400 mb-1">Temperature</p>
              <p className="text-lg font-bold text-white">{planet.temperature}K</p>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-yellow-900/40 to-black/60 rounded-xl border border-yellow-500/30">
              <Star className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <p className="text-xs text-gray-400 mb-1">Mass</p>
              <p className="text-lg font-bold text-white">{planet.mass}M⊕</p>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-green-900/40 to-black/60 rounded-xl border border-green-500/30">
              <Clock className="w-8 h-8 text-green-400 mx-auto mb-3" />
              <p className="text-xs text-gray-400 mb-1">Orbit</p>
              <p className="text-lg font-bold text-white">{planet.orbitalPeriod}d</p>
            </div>
          </div>

          <div className="space-y-3">
            <p className="text-sm text-gray-400 font-medium">Habitability Score</p>
            <div className="flex items-center space-x-3">
              <div className="flex-1 bg-gray-800/50 rounded-full h-4 overflow-hidden">
                <div
                  className={`h-4 rounded-full shadow-lg transition-all duration-1000 ${
                    planet.habitabilityScore >= 80
                      ? 'bg-gradient-to-r from-emerald-400 via-green-400 to-cyan-500'
                      : planet.habitabilityScore >= 60
                      ? 'bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400'
                      : 'bg-gradient-to-r from-red-500 via-pink-500 to-purple-500'
                  }`}
                  style={{ width: `${planet.habitabilityScore}%` }}
                ></div>
              </div>
              <span className="text-lg font-bold text-white">{planet.habitabilityScore}%</span>
            </div>
          </div>

          <div className="space-y-4">
            <p className="text-sm text-gray-400 font-medium">Key Minerals</p>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="flex justify-between p-2 bg-black/30 rounded-lg">
                <span className="text-gray-300">Water:</span>
                <span className="text-cyan-400 font-bold">{planet.minerals.water}%</span>
              </div>
              <div className="flex justify-between p-2 bg-black/30 rounded-lg">
                <span className="text-gray-300">Iron:</span>
                <span className="text-orange-400 font-bold">{planet.minerals.iron}%</span>
              </div>
              <div className="flex justify-between p-2 bg-black/30 rounded-lg">
                <span className="text-gray-300">Carbon:</span>
                <span className="text-purple-400 font-bold">{planet.minerals.carbon}%</span>
              </div>
              <div className="flex justify-between p-2 bg-black/30 rounded-lg">
                <span className="text-gray-300">Silicon:</span>
                <span className="text-gray-400 font-bold">{planet.minerals.silicon}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-purple-900 relative overflow-hidden">
      {/* Cosmic Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent"></div>
      <div className="absolute top-0 left-0 w-full h-full opacity-40" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Ccircle cx='30' cy='30' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
      }}></div>
      
      <div className="relative z-10 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center mb-8">
            <button
              onClick={onBack}
              className="flex items-center space-x-3 text-white hover:text-cyan-400 transition-all duration-300 bg-black/30 backdrop-blur-sm px-4 py-2 rounded-xl border border-gray-700/50 hover:border-cyan-500/50"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Return to Cosmos</span>
            </button>
          </div>

          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent mb-4">
              Cosmic World Comparison
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Compare two exoplanets side by side to analyze their unique characteristics and potential for life
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <ComparisonCard planet={selectedPlanets[0]} index={0} />
            <ComparisonCard planet={selectedPlanets[1]} index={1} />
          </div>

          {selectedPlanets[0] && selectedPlanets[1] && (
            <div className="bg-gradient-to-br from-gray-900/80 via-black/60 to-gray-900/80 backdrop-blur-xl rounded-2xl p-8 border border-purple-500/30 shadow-2xl shadow-purple-500/10">
              <h3 className="text-2xl font-bold text-white mb-8 text-center">Comparison Analysis</h3>
              <div className="grid md:grid-cols-3 gap-8">
                <div className="text-center p-6 bg-gradient-to-br from-emerald-900/40 to-black/60 rounded-xl border border-emerald-500/30">
                  <h4 className="text-lg font-semibold text-white mb-3">More Habitable</h4>
                  <p className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-green-400 bg-clip-text text-transparent">
                    {selectedPlanets[0].habitabilityScore > selectedPlanets[1].habitabilityScore
                      ? selectedPlanets[0].name
                      : selectedPlanets[1].name}
                  </p>
                  <p className="text-sm text-gray-400 mt-2">
                    {Math.max(selectedPlanets[0].habitabilityScore, selectedPlanets[1].habitabilityScore)}% habitability
                  </p>
                </div>
                <div className="text-center p-6 bg-gradient-to-br from-blue-900/40 to-black/60 rounded-xl border border-blue-500/30">
                  <h4 className="text-lg font-semibold text-white mb-3">Closer to Earth</h4>
                  <p className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                    {selectedPlanets[0].distance < selectedPlanets[1].distance
                      ? selectedPlanets[0].name
                      : selectedPlanets[1].name}
                  </p>
                  <p className="text-sm text-gray-400 mt-2">
                    {Math.min(selectedPlanets[0].distance, selectedPlanets[1].distance)} light years
                  </p>
                </div>
                <div className="text-center p-6 bg-gradient-to-br from-cyan-900/40 to-black/60 rounded-xl border border-cyan-500/30">
                  <h4 className="text-lg font-semibold text-white mb-3">More Water</h4>
                  <p className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                    {selectedPlanets[0].minerals.water > selectedPlanets[1].minerals.water
                      ? selectedPlanets[0].name
                      : selectedPlanets[1].name}
                  </p>
                  <p className="text-sm text-gray-400 mt-2">
                    {Math.max(selectedPlanets[0].minerals.water, selectedPlanets[1].minerals.water)}% water content
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};